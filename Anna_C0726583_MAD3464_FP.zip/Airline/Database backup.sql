-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 02, 2018 at 05:39 AM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `airline`
--

-- --------------------------------------------------------

--
-- Table structure for table `farechart`
--

CREATE TABLE `farechart` (
  `chart_no` int(3) NOT NULL,
  `flight_no` int(4) NOT NULL,
  `airline` varchar(25) NOT NULL,
  `class` varchar(15) NOT NULL,
  `fare_rate` double(4,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `farechart`
--

INSERT INTO `farechart` (`chart_no`, `flight_no`, `airline`, `class`, `fare_rate`) VALUES
(1, 1001, 'Luftansa', 'economy', 10.30),
(2, 1002, 'Qatar', 'economy', 8.20),
(3, 1001, 'Luftansa', 'business', 9.50),
(5, 2010, 'Indian Airlines', 'First Class', 12.10);

-- --------------------------------------------------------

--
-- Table structure for table `flightrepo`
--

CREATE TABLE `flightrepo` (
  `flightNo` int(4) NOT NULL,
  `airline` varchar(25) NOT NULL,
  `itenary_id` int(2) NOT NULL,
  `depart_date` varchar(10) NOT NULL,
  `depart_time` varchar(5) NOT NULL,
  `pilot_name` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `flightrepo`
--

INSERT INTO `flightrepo` (`flightNo`, `airline`, `itenary_id`, `depart_date`, `depart_time`, `pilot_name`) VALUES
(1000, 'Fly Dubai', 1, '2016-05-23', '', 'John Kelly'),
(1001, 'Luftansa', 1, '2018-04-14', '', 'William'),
(1002, 'Qatar', 1, '2018-04-14', '', 'Rooney'),
(1004, 'Saudi', 0, '2018-06-31', '12:00', 'Raisa'),
(1005, 'Qatar', 0, '2018-07-31', '14:00', 'Milad'),
(1120, 'Air India', 3, '2018-08-30', '12:00', 'Rohan');

-- --------------------------------------------------------

--
-- Table structure for table `itenary`
--

CREATE TABLE `itenary` (
  `itenary_id` int(10) UNSIGNED NOT NULL,
  `startPoint` varchar(25) NOT NULL,
  `endPoint` varchar(25) NOT NULL,
  `airmiles` double(6,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `itenary`
--

INSERT INTO `itenary` (`itenary_id`, `startPoint`, `endPoint`, `airmiles`) VALUES
(1, 'mumbai', 'bombay', 2333.00),
(3, 'COK', 'TRV', 200.00),
(4, 'CST', 'YYZ', 1300.34);

-- --------------------------------------------------------

--
-- Table structure for table `pass_list`
--

CREATE TABLE `pass_list` (
  `pass_id` int(2) NOT NULL,
  `pass_name` varchar(25) NOT NULL,
  `seats` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `reservation`
--

CREATE TABLE `reservation` (
  `ReservationNo` int(11) NOT NULL,
  `resv_id` double(5,2) NOT NULL,
  `pass_name` varchar(25) NOT NULL,
  `seat_class` varchar(15) NOT NULL,
  `depart_date` varchar(10) NOT NULL,
  `flight_no` varchar(5) NOT NULL,
  `airline` varchar(25) NOT NULL,
  `pilot_name` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reservation`
--

INSERT INTO `reservation` (`ReservationNo`, `resv_id`, `pass_name`, `seat_class`, `depart_date`, `flight_no`, `airline`, `pilot_name`) VALUES
(4, 0.25, 'sreejith', 'null', '2018-04-14', 'null', 'Luftansa', 'William'),
(6, 0.53, 'sreejith', 'business', '2018-04-14', '1001', 'Luftansa', 'William'),
(7, 0.18, 'sreejith', 'economy', '2018-04-14', '1002', 'Qatar', 'Rooney'),
(8, 0.17, 'sree', 'business', '2018-04-14', '1002', 'Qatar', 'Rooney'),
(9, 0.83, 'Anu', 'First Class', '2018-08-30', '1120', 'Air India', 'Rohan'),
(10, 0.92, 'Ram Kumar', 'economy', '2018-08-30', '1120', 'Air India', 'Rohan'),
(11, 0.21, 'Bipin', 'economy', '2018-08-30', '1120', 'Air India', 'Rohan'),
(12, 0.16, 'Unni', 'economy', '2018-08-30', '1120', 'Air India', 'Rohan'),
(13, 0.83, 'Donnley', 'economy', '2018-08-30', '1120', 'Air India', 'Rohan'),
(14, 0.50, 'Jini', 'First Class', '2018-08-30', '1120', 'Air India', 'Rohan'),
(15, 0.68, 'Freddy', 'economy', '2018-08-30', '1120', 'Air India', 'Rohan'),
(16, 0.40, 'Tony', 'economy', '2018-08-30', '1120', 'Air India', 'Rohan');

-- --------------------------------------------------------

--
-- Table structure for table `userdb`
--

CREATE TABLE `userdb` (
  `userID` int(11) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userdb`
--

INSERT INTO `userdb` (`userID`, `username`, `password`) VALUES
(1, 'sree', '123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `farechart`
--
ALTER TABLE `farechart`
  ADD PRIMARY KEY (`chart_no`);

--
-- Indexes for table `flightrepo`
--
ALTER TABLE `flightrepo`
  ADD PRIMARY KEY (`flightNo`);

--
-- Indexes for table `itenary`
--
ALTER TABLE `itenary`
  ADD PRIMARY KEY (`itenary_id`);

--
-- Indexes for table `pass_list`
--
ALTER TABLE `pass_list`
  ADD PRIMARY KEY (`pass_id`);

--
-- Indexes for table `reservation`
--
ALTER TABLE `reservation`
  ADD PRIMARY KEY (`ReservationNo`);

--
-- Indexes for table `userdb`
--
ALTER TABLE `userdb`
  ADD PRIMARY KEY (`userID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `farechart`
--
ALTER TABLE `farechart`
  MODIFY `chart_no` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `itenary`
--
ALTER TABLE `itenary`
  MODIFY `itenary_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `pass_list`
--
ALTER TABLE `pass_list`
  MODIFY `pass_id` int(2) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reservation`
--
ALTER TABLE `reservation`
  MODIFY `ReservationNo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
