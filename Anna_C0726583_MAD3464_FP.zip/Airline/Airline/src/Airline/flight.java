/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Airline;

import java.util.Scanner;

/**
 *
 * @author annanekhashabu
 */

/**
 *
 * Class to manage the flight details. Functions to chart a flight as per the necessary details is provided by this class.
 */
public class flight extends itenary implements departdate 
{
    public int flight_no;
    public String pilot_name;
    public String airline_name;
    public String depart_date;
    public String depart_time;
    public String itenary_ID; 
    public int flight_itenary_ID; 
    Scanner input = new Scanner(System.in);
     
    // method to get the relevant iteanary for the flight for charting a flight.
    public void getItenary()
    {
        itenary obj_iter = new itenary();
        System.out.println("Please enter the itenary ID from the list to be linked to this flight. ");  
        
        obj_iter.display_itenaries();
        
        System.out.println("Enter the itenary ID :");
        this.flight_itenary_ID = input.nextInt();

    }
    
    
    // method to pool the flight details when adding a flight to the repo.
    public  void chart_flight()
    {
        
         System.out.println("Enter the airline name : ");
         this.airline_name = input.nextLine();
        
        // method to set the departure date.
        this.depart_time = set_time();
        
        // method to set the departure date.
        this.depart_date = set_date();
    
        System.out.println("Enter the pilot name :");
        this.pilot_name = input.nextLine();
        
        System.out.println("Enter the flight number : ");
        this.flight_no = input.nextInt();
        // code to get the itenary for the flight.
        getItenary();
        
    }

    @Override
    public String set_date()
    {
        System.out.println("Enter the departure date : ");
        String date = input.nextLine();
        return (date);
    }

    @Override
    public String set_time() 
    {
        System.out.println("Enter the departure time : ");
        return (input.nextLine());
    }
    
    

}
