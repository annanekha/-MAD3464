/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Airline;

import com.sun.org.apache.xerces.internal.impl.xpath.regex.Match;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

/**
 *
 * @author annanekhashabu
 */


/**
 *
 * Passenger class used to book,cancel and for making functionalities.
 * 
 */
public class Passenger extends flight

{
   public String passenger_name ;
   public String passenger_ID ;
   public String seat_type ;
   public String reservation_id;
   public char char_choice;
   public int int_choice;
   public boolean confirm_flag;
   public double rate;
   public String passenger_sql_query = "";
   public String passenger_sql_query_insert ="";
   
   public int Passenger_flight_no;
   public String Passenger_airline;
   public String Passenger_pilot_name;
   
   public String payment_card_no;
   public long internet_banking_mobile_number;
   public String internet_banking_OTP;

   Scanner input = new Scanner(System.in);

 /**
 *
 * bookFlight() Method to book a flight.
 * 
 */
   public void bookFlight()
     { 
         Ticket tck_obj = new Ticket();
         confirm_flag = false;              // flag to confirm wherther flight is found for a given itenary id and depart date.
         
         System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>> Flight reservation panel <<<<<<<<<<<<<<<<<<<<<<<<");
         System.out.println("Enter your user name : ");
         this.passenger_name = input.nextLine();
         
         System.out.println("Choose your itenary : ");
         
         // method to diplay the available itenaries.
         //****************************************************************************************************
          this.display_itenaries();
          System.out.println(">>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<");
         //****************************************************************************************************
         
          System.out.println("Enter the itenary id from the above list of services: ");
          this.itenary_ID = input.nextLine();
          
          System.out.println("Enter the departure date(yyyy-MM-dd) to start looking for available flights : ");
          this.depart_date = input.nextLine();
          
          // code to display the available flights for the given itenary and departure date.
         //****************************************************************************************************
          FRepository repo = new FRepository();
          confirm_flag = repo.listFlight(this.itenary_ID, this.depart_date);
          
          if (confirm_flag == false)                // recall bookFlight() method to reconfirm itenary id and depart date.
          {
              bookFlight();
          }
        
          System.out.println("Choose your flight number :");
          Passenger_flight_no = input.nextInt();
          
          // code to reserve the seat and compute rate  as per the class 
         //****************************************************************************************************
         // call object of FlightSegmentreservation and compute price
         FlightSegmentReservation FSR = new FlightSegmentReservation();
         this.rate =  FSR.computePrice(Passenger_flight_no,this.itenary_ID);
         this.seat_type = FSR.seat_type;
         
         // code to confirm a ticket and initiate payment process after comparing prices of airlines with same service on same day.
         //****************************************************************************************************
           System.out.println("Compare prices ? (Y/N)");        
           char_choice = input.next().charAt(0);

           if ( (char_choice == 'Y' ) || (char_choice == 'y') ) 
                {
                //   Ticket tck_obj = new Ticket();
                   // System.err.println("sdcdsc = " + this.itenary_ID);
                    tck_obj.compPrice(itenary_ID,depart_date);
                   
                    System.out.println("Choose different flight ? (Y/N)");
                    char_choice = input.next().charAt(0);
                    
                    if ( (char_choice == 'Y' ) || (char_choice == 'y') ) 
                         {
                             System.out.println("Enter the new flight number : ");
                             Passenger_flight_no = input.nextInt();
                             this.rate =  FSR.computePrice(Passenger_flight_no,this.itenary_ID);
                     
                         }
                        
                }
           
         if(confirm_flag == true)
         {
             this.confirmTicket();
             this.makePayment();
         }
     }     
   
   
   // code to cancel a flight. The passenger unique id is the user name ( email.id) and it is used to pull the list of reservations made 
   // under that user-name.
   
 /**
 *
 * cancelFlight() Method to cancel a flight.
 * 
 */
   public void cancelFlight()
     { 
      
         System.out.println("Enter the passenger user name for flight cancellation  :");
         this.passenger_ID = input.nextLine();
         
        
         sql_query = "Select resv_id,seat_class,depart_date,flight_no,airline from reservation where pass_name = '"+this.passenger_ID+"';";
         try 
         {
             res = DB_object.executeSQL(sql_query);
             while (res.next()) 
             {                 
                 System.out.println("reservation_id :" + res.getString(1)+ " Seat class :" + res.getString(2)+ " Departure Date :" + res.getString(3)+ " Flight_no"  + res.getString(4)+ " Airline :" + res.getString(5));
             }
             
         } catch (Exception e)
         {
             System.out.println("SQL Exception . class : Passenger.. method : cancelFlight() " + e);
         }
      
        //****************************************************************************************************
        
         System.out.println("Enter the reservation id  for cancellation  :");
         this.reservation_id = input.nextLine();
   
         // code to delete the reservation from the DB. 
         //****************************************************************************************************
         
         sql_query = "DELETE from reservation WHERE resv_id = '"+this.reservation_id+"';";
         try 
         {
             DB_object.executeSQL_update(sql_query);
             if(DB_object.result > 0) 
             {
                System.out.println("Reservation is deleted successfully!");
             }    
             else
             {
                System.out.println("Deletion failed !!");
             }      
             
         } catch (Exception e)
         {
             System.out.println("SQL Exception . class : Passenger.. method : cancelFlight() " + e);
         }
         
         
         
         confirm_flag = true;
         
         
         if(confirm_flag == true)
         {
             System.out.println("The flight reservation "+this.reservation_id+ " is cancelled successfully !!");
         }
         else
         {
             System.out.println("Flight cancellation aborted !!!");
         }
         
         
     } 
   
   // code to make the payment for the ticket.
 /**
 *
 * makePayment() Method to make a payment.
 * 
 */
   public void makePayment()
     { 
         System.out.println("Choose your payment method..\n 1. Credit \n 2. Debit \n 3. Internet banking");
         int_choice = input.nextInt();
          
         switch(int_choice)
         {
             case 1 : { 
                        System.out.println("Payment through credit");
                        System.out.println("Please enter the credit card number : ");
                        payment_card_no = input.nextLine();
                        payment_card_no = input.nextLine();
                        System.out.println("Confirm to pay " +this.rate+ " by credit card (Y/N) ?");
                        char_choice = input.next().charAt(0);
                        
                        if ((char_choice == 'Y') || (char_choice == 'y'))
                        {
                            System.out.println("Your payment is confimed !! ");  
                        }
                        else
                        {
                           this.makePayment();   
                        }
                        
                        break;
                      }
             
             case 2 : { 
                        
                        System.out.println("Payment through debit");
                        System.out.println("Please enter the debit card number : ");
                        payment_card_no = input.nextLine();
                        payment_card_no = input.nextLine();
                        
                        System.out.println("Confirm to pay " +this.rate+ " by debit card (Y/N) ?");
                        char_choice = input.next().charAt(0);
                        
                        if ((char_choice == 'Y') || (char_choice == 'y'))
                        {
                            System.out.println("Your payment is confimed !!");  
                        }
                        else
                        {
                           this.makePayment();   
                        }
                        
                        break;
                      }
              
              
              case 3 : { 
                        
                        System.out.println("Payment through online banking");
                        System.out.println("Routing to your financial institution's secure portal ");
                       
                        System.out.println("Please enter the registerd banking mobile number : ");
                        internet_banking_mobile_number = input.nextLong();
                      
                        System.out.println("An one-time-password (OTP) will be sent to your registered mobile number shortly.... ");
                        System.out.println("Please enter the received OTP : ");
                        internet_banking_OTP = input.nextLine();
                        
                        System.out.println("Confirm to pay " +this.rate+ " by internet banking (Y/N) ?");
                        char_choice = input.next().charAt(0);
                        
                        if ((char_choice == 'Y') || (char_choice == 'y'))
                        {
                            System.out.println("Your payment is confimed !!");  
                        }
                        else
                        {
                           this.makePayment();   
                        }
                        
                        break;
                      }
              
              default: {
                            System.out.println("Invalid entry !!!!");
                       }
         }
         
         
         
     }
 /**
 *
 * confirmTicket() Method to make a confirm the ticket
 * 
 */
   
    public void confirmTicket()
    {
        System.out.println("Confirm this ticket ? (Y/N)");
        char_choice = input.next().charAt(0);
        
        if((char_choice == 'Y')||(char_choice == 'N'))
                {
                    Double reserv_id = Math.random();
                    // code to add reservation to reservation table and passenger details to passenger table.
                     try {
                            passenger_sql_query = "select flightNo,airline,pilot_name from flightrepo where flightNo = '"+Passenger_flight_no +"';";    
                            	
                            res = DB_object.executeSQL(passenger_sql_query);
                            
                            while (res.next())
                            {                             
                              this.Passenger_airline = res.getString(2);
                              this.Passenger_pilot_name = res.getString(3);
                            }
                
                            passenger_sql_query_insert = "insert into reservation (resv_id,pass_name,seat_class,depart_date,flight_no,airline,pilot_name) VALUES( '"+ reserv_id +"' , '"+ this.passenger_name +"','"+  this.seat_type +"', '"+depart_date+"','"+ this.Passenger_flight_no +"','"+this.Passenger_airline +"','"+ this.Passenger_pilot_name +"');";                      
                                    
                            DB_object.executeSQL_update(passenger_sql_query_insert);
                            System.out.println("Reservation successful !!! ");
                            
                         }
                         catch (SQLException e) 
                               {
                                 System.err.println("Sql Exception : class : confirmTicket() :: " + e);
                               }
           
                       System.out.println("Ticket confirmed...!");
                }
        
    }
    
    // list the reservations made by the passenger.
 /**
 *
 * list_reservations() Method to listout all the reservations.
 * 
 */
    public  void list_reservations()
    {
        sql_query = "Select resv_id,seat_class,depart_date,flight_no,airline from reservation;";
         try 
         {
             res = DB_object.executeSQL(sql_query);
             while (res.next()) 
             {                 
                 System.out.println("reservation_id :" + res.getString(1)+ " Seat class :" + res.getString(2)+ " Departure Date :" + res.getString(3)+ " Flight_no: "  + res.getString(4)+ " Airline :" + res.getString(5));
             }
             
         } catch (Exception e)
       
         {
             System.out.println("SQL Exception . class : Passenger.. method : list_reservations() " + e);
         }
    }
    
    
}
