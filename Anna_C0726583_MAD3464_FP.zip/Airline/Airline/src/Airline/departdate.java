/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Airline;

import java.util.Date;

/**
 *
 * @author annanekhashabu
 */

/**
 *
 * interface providing the depart time and depart date details.
 */
public interface departdate 


{
    public String depart_date = "";
    public String depart_time = "";
 
    public String set_date();
    public String set_time();
    
    
    
}
