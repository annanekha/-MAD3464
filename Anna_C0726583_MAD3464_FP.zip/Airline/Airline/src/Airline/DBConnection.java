/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Airline;

import com.mysql.jdbc.Connection;

import java.sql.*;


/**
 *
 * @author annanekhashabu
 */

/**
 * DBConnection - To perform database operations.
 * 
 */
public class DBConnection 

{
    private static final String USERNAME    = "root";
    private static final String PASSWORD    = "";
    private static final String CONN_STRING = "jdbc:mysql://localhost:3306/airline?autoReconnect=true&useSSL=false";
    ResultSet res ;
    Connection conn ;
    Integer result = 0;


    public DBConnection()
    
    {
        this.connect();
    }
    
 /**
 * connect () method - To create connection with the DB.
 * 
 */
    public void connect ()
    {
        
        
        try 
        {
            
            conn =  (Connection) DriverManager.getConnection(CONN_STRING, USERNAME, PASSWORD);
            System.out.println("Connected !");
        } catch (SQLException e)
        {
            System.err.println("Connection error !");
        }
    }
   
    
 /**
 * 
 * 
 * executeSQL_update(String sql) - method for performing insertion and Updation.
 * @param sql - Variable for storing sql queries. 
 */
    
    public void executeSQL_update(String sql) throws SQLException
    {
          Statement stat = conn.createStatement();
          result  = stat.executeUpdate(sql);
    }
    
    // method for pulling data from DB.
     public ResultSet executeSQL(String sql) throws SQLException
             
    {
          Statement stat = conn.createStatement();
          res = stat.executeQuery(sql);
          return res;
          
    }
}






