/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Airline;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author annanekhashabu
 */

/**
 *
 * FlightSegmentReservation : Class used to allocate seat type and to compute the ticket price.
 */

public class FlightSegmentReservation extends flight 

{
    public String seat_type ;
    private double airmiles;
    private double charge;
    private double ticket_charge;
    public String sql_query_airmiles = "";
    public String sql_query_fare = "";
    public DBConnection DB_object ;
    public ResultSet res ;
    
    Scanner input = new Scanner(System.in);

    public FlightSegmentReservation()
    {
      DB_object = new DBConnection(); 
    }
 
 /**
 *
 * computePrice(Integer flight_no,String itenary_num) : Method for calculating the price of a selected seat.
 * @param flight_no Variable to hold the flight number.
 * @param itenary_num Variable to hold the itinerary number.
 */       
    public double computePrice(Integer flight_no,String itenary_num)
    {
        if (flight_no == 0) 
        {
            System.out.println("No flight number is chosen !");
        }
            
         else
        {
           System.out.println("Enter the type of seat from the list  to reserve :");
           System.out.println("1. First Class \n2.Business class\n3. Economy");
           this.seat_type = input.nextLine();
        
           switch (seat_type)
               
            {
                case "1" : {
                              seat_type = "First Class";
                              break;
                           }
                
                case "2" : {
                              seat_type = "business";
                              break;
                           }
                
                case "3" : {  
                              seat_type = "economy";
                              break;
                           }
            }
           
           System.out.println("Computing ticket price :");
        
        // code to pull the itenary details with airmiles and flight repository with charges and calculate the final price.
        //******************************************************************************************************************
           sql_query_airmiles = "Select airmiles from itenary where itenary_id = '"+ itenary_num +"' ;";
           
            try {
                res = DB_object.executeSQL(sql_query_airmiles);
                
                } catch (Exception e)
                 {
                     System.out.println("Sql exception -- class :FlightSegmentReservation()  method : computePrice(String flight_no, String itenary_num)");
                 }
           
            
            try {
                     while (res.next())
                     {
                        this.airmiles = res.getDouble(1);
                        
                     }
                } catch (SQLException ex)
                {
                    System.out.println("error --" + ex);
                    System.out.println("Data read error -- class :FlightSegmentReservation()  method : computePrice(String flight_no, String itenary_num)");
                }

          //  System.out.println("test data airmiles " + this.airmiles);
            
         // code to pull the fare rate as per the given flight number and class.
        //******************************************************************************************************************
           sql_query_fare = "Select fare_rate from farechart where flight_no = '"+ flight_no +"' and class = '"+ this.seat_type +"'  ;";
           
            try {
                res = DB_object.executeSQL(sql_query_fare);
                
                } catch (Exception e)
                 {
                     System.err.println("error : " + e + "\n" + sql_query_fare );
                    
                     System.out.println("Sql exception -- class :FlightSegmentReservation()  method : computePrice(String flight_no, String itenary_num)");
                 }
           
            
            try {
                     while (res.next())
                     {
                        this.charge = res.getDouble(1);
                     }
                } catch (SQLException ex)
                {
                    System.out.println("Data read error -- class :FlightSegmentReservation()  method : computePrice(String flight_no, String itenary_num)");
                }
 
          //  System.out.println("test data fare rate " + this.charge);
            
            this.ticket_charge = this.airmiles * this.charge;
        //******************************************************************************************************************
        
        
           System.out.println("Total ticket charge for the flight is : C$" + this.ticket_charge);
          
        }
       return this.ticket_charge;
    }
}
