/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Airline;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

/**
 *
 * @author annanekhashabu
 */


/**
 *  Main / Driver class of the MyAirline system. This class acts as the basis for performing all operations.
 */
public class AirlineReservation implements DB_Tables

{
    
   /**
    * MyAirline - Main class invoking the program.
    * @param args is the command line argument
    */
    public static void main(String[] args) throws SQLException
    {
        // TODO code application logic here
        
        String query = "";
        ResultSet res = null ;
        Boolean flag  = false;
        
        
        DBConnection DB = new DBConnection();
        DB.connect();
        
        Scanner input = new Scanner(System.in);
        String user_name,password;
        int ch = 0;
        char choice;
      
        System.out.println(" Welcome to MyAirline \n");
        //System.out.println(" Login ");
        
        System.out.println("### Please enter username and password to proceed ###\n");
        System.out.println("UserName :");
        user_name = input.nextLine();
        
        System.out.println("Passoword :");
        password = input.nextLine();
        
        // code to check the database user name and password. If matches, login to the main reservation screen else display error msg.
        //***************************************************************************************************************************
        try {
            query = "Select * from " + user_DB + " where username = '"+ user_name +"' and password = '"+ password +"';";        
            res = DB.executeSQL(query);
           
            while(res.next())
            {
              if ((user_name.equals(res.getString(2)) ) &&(password.equals(res.getString(3))))
                  {
                     System.out.println("Login Successful !!");
                     flag = true;
                     break;
                  } 
               else
                  {              
                     continue;
                  } 
 
            }
            
            if(flag == false)
                 {
                     System.out.println("Invalid login crediantials !");
                  } 
                
            
        } catch (Exception e) 
        {
            System.out.println("Sql Exception : " + e);
        }
            
         
        
        //***************************************************************************************************************************
        
        // System.out.println("Login successful !!! :");
        
        while (flag == true) 
        {
            System.out.println("\n\n\n\n");
            System.out.println(" Welcome to MyAirline \n");
            System.out.println("Choose the following options to continue:\n");
            System.out.println("1. Make a reservation");
            System.out.println("2. Passanger list");
            System.out.println("3. Flight Repository");
            System.out.println("4. Register Reservation");
            System.out.println("5. Manage Fares");
            System.out.println("6. Exit console");

            System.out.println("Option : ");
            ch = input.nextInt();

            switch (ch) 
            {
                case 1: {
                            System.out.println(" Welcome to the Airline reservation system \n");
                            System.out.println(" Make a Reservation ");
                            flag = false;
                                                     
                            Passenger pass_obj = new Passenger();
                            pass_obj.bookFlight();
                            
                            break;
                            
                        }

                case 2: {
                            System.out.println("Welcome to MyAirline\n");
                            System.out.println(" Passenger List ");
                           
                            System.out.println("1. Add Passengers");
                            System.out.println("2. Remove Passengers");
                            System.out.println("3. List Passengers");
                            
                            ch = input.nextInt();
                            PassengerList PList = new PassengerList();
                            
                            
                            if(ch == 1)
                            {
                               
                               PList.addPassenger();
                               flag = true;
                            }
                            else if (ch == 2)
                            {                               
                                PList.removePassenger();
                                flag = true; 
                            }
                           
                            else if (ch == 3)
                            {
                                PList.listPass();
                                flag = true; 
                            }
                            else 
                            {
                                System.out.println("Invalid entry");
                                flag = true;
                            }
                            
                            break;
  
                        }

                case 3: {
                            System.out.println(" Welcome to MyAirline\n");
                            System.out.println(" Flight Repository ");
                            
                            System.out.println("1. Add Flight");
                            System.out.println("2. Remove Flight");
                            System.out.println("3. List Flights");
                            System.out.println("Choose Option : ");
                            ch = input.nextInt();
                            FRepository fRepoObj = new FRepository();
                            
                            if(ch == 1)
                            {
                               
                               fRepoObj.addFlight();
                               flag = true;
                            }
                            else if (ch == 2)
                            {                               
                                fRepoObj.removeFlight();
                                flag = true; 
                            }
                           
                            else if (ch == 3)
                            {
                                fRepoObj.listFlight();
                                flag = true; 
                            }
                            else 
                            {
                                System.out.println("Invalid entry");
                                flag = true;
                            }
                            
                            break;
   
                           
                        }

                
                case 4: {
                            System.out.println(" Welcome to MyAirline \n");
                            System.out.println(" Reservation Register ");
                            System.out.println("1. Cancel Reservations");
                            System.out.println("2. List Reservations");
                            System.out.println("Option : ");
                            ch = input.nextInt();
                            Passenger pass_obj = new Passenger();
                            
                            if(ch == 1)
                            {
                               
                               pass_obj.cancelFlight();
                               flag = true;
                            }
                            else if (ch == 2)
                            {
                                pass_obj.list_reservations();
                                flag = true; 
                            }
                            else 
                            {
                                System.out.println("Invalid entry");
                                flag = true;
                            }
                            
                            break;

                        }

                case 5: {
                            System.out.println(" Welcome to MyAirline \n");
                            System.out.println(" Fare Management ");
                            System.out.println("1. Add new Fares");
                            System.out.println("2. Delete Fares");
                            System.out.println("3. Update Fares");
                            System.out.println("Option : ");
                            ch = input.nextInt();
                            fares fare_obj = new fares();
                            
                            if(ch == 1)
                            {
                               
                               fare_obj.insert_new_fare();
                               flag = true;
                            }
                            else if (ch == 2)
                            {
                               fare_obj.delete_fare();
                               flag = true; 
                            }
                            else if (ch == 3)
                            {
                               fare_obj.update_fare();
                               flag = true; 
                            }
                            else 
                            {
                                System.out.println("Invalid entry");
                                flag = true;
                            }
                            
                            break;

                        }
                
                case 6: {
                            System.out.println("Exit ? (Y/N) ");
                            choice = input.next().charAt(0);
                            
                            if ((choice == 'Y') || (choice == 'y'))
                            {
                                System.exit(1);
                            }  
                         
                            break;

                        }
                
                default: {
                            System.out.println("Invalid entry!!!!");
                            break;
                         }
            }

        }

    }
}