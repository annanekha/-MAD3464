/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Airline;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

/**
 *
 * @author annanekhashabu
 */

/**
 *
 *  Class used to manage the service fares of different flights as per the business.
 */
public class fares 

{

    public fares()
    {
        rate = 0.0;
        airline_name = "";
        flight_no = "";
        seat_class = "";
        DB_object = new DBConnection();
        
    }
    
    
    private double rate ;
    private String airline_name,flight_no,seat_class,remove_fare_number,update_fare_number ;
    public boolean flag ;
    public ResultSet res ;
    public DBConnection DB_object ;
    public String fare_sql_query_insert,fare_sql_query_delete,fare_sql_query_update,fare_sql_query_display;
    public Double  new_fare_rate= 0.0;
    
    Scanner input = new Scanner(System.in);
    
    // insert new fare detail into DB
    public void insert_new_fare()
    {
        
                            Scanner input = new Scanner(System.in);
        
                            System.out.println("<<<<<<<< Welcome to the Airline reservation system >>>>>>>\n");
                            System.out.println("<<<<<<<<<<<<<<<<<<<<< Insert new Fare >>>>>>>>>>>>>>>>>>>>");
                            System.out.println("\n\n");
                           
                            System.out.println("Enter the fight number :");
                            this.flight_no = input.nextLine();
                            
                            System.out.println("Enter the airline name :");
                            this.airline_name = input.nextLine();
                            
                            System.out.println("Enter the seating class:");
                            this.seat_class = input.nextLine();
                            
                            System.out.println("Enter the fare rate :");
                            this.rate = input.nextDouble();
                                               
                           
                            //*******************************************************************************************
                            // code to write data into to DB.
                            fare_sql_query_insert = "insert into farechart (flight_no,airline,class,fare_rate) VALUES( '"+ this.flight_no +"' , '"+this.airline_name +"','"+  this.seat_class +"', '"+this.rate+"');";                      
                  
                            try {
                                  DB_object.executeSQL_update(fare_sql_query_insert);
                                  flag = true;
                                } 
                            catch (Exception e) 
                               {
                                  System.out.println("Sql Exception found at : " +e );
                                  flag = false;
                               }
                            
                            if(flag)
                            System.out.println("Fare added successfully !! ");
                
                           //********************************************************************************************
                            
                
    }
    
    // method to retrieve the fares from DB.
    public void display_fare()
   
    {
                            // code to retrieve data from the DB and store in class variables.
                            //********************************************************************************
                             try {
                                      fare_sql_query_display = "select * from farechart;";                         
                                      res = DB_object.executeSQL(fare_sql_query_display);                   
                                 }
                               
                             catch (SQLException e) 
                                 {
                                    System.out.println("Sql Exception in reading data from DB: method : display_fare()  : class : fares" + e);
                                 }
                                
                            try {
                                    while(res.next())
                                     {   
                                         System.out.println(">>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<");
                                         System.out.println("Fare   no#  :" + res.getString(1));
                                         System.out.println("Flight no#  :" + res.getString(2));
                                         System.out.println("Airline     :" + res.getString(3));
                                         System.out.println("class       :" + res.getString(4));   
                                         System.out.println("Fare Rate   :" + res.getString(5));
                                
                                         flag = true;
                                      }
                                }                                
                            catch (Exception e)
                               {
                                  System.err.println("Exception at try-catch for pulling itenary DB records  .. class: fares --> method : display_fare() --> " + e);
                               }    
        
    }
    
    // method to delete a fare
    public void delete_fare()
    {
        this.display_fare();
        System.out.println("Enter the fare no: to be removed from the above list :\n");
        
        remove_fare_number = input.nextLine();
        
        fare_sql_query_delete  = "DELETE from farechart WHERE chart_no = '"+this.remove_fare_number+"';";
         
        try 
         {
             DB_object.executeSQL_update( fare_sql_query_delete);
             if(DB_object.result > 0) 
             {
                System.out.println("Fare is deleted successfully!");
             }    
             else
             {
                System.out.println("Deletion failed !!");
             }      
             
         } catch (Exception e)
         {
             System.out.println("SQL Exception . class : fares .. method : delete_fare() " + e);
         }
        
    }
    
    // method to update the fare int the DB.
     public void update_fare()
     {
         this.display_fare();
         
         System.out.println("Enter the fare no: to be updated from the above list :\n"); 
         update_fare_number = input.nextLine();
         
         System.out.println("Enter the new fare rate :"); 
         new_fare_rate = input.nextDouble();
       
         fare_sql_query_update  = "UPDATE farechart  SET fare_rate = '"+this.new_fare_rate+"' WHERE chart_no = '"+this.update_fare_number+"';";

        try 
         {
             DB_object.executeSQL_update(fare_sql_query_update);
             if(DB_object.result > 0) 
             {
                System.out.println("Fare is updated successfully!");
             }    
             else
             {
                System.out.println("Updation failed !!");
             }      
             
         } catch (Exception e)
         {
             System.out.println("SQL Exception . class : fares .. method : update_fare() " + e);
         }

     }
    
    
    
    // method to return a fare.
    public double return_fare()
    {
        return this.rate;
    }
    
    // method to set a input fare 
      public void set_fare(double input_fare)
    {
        this.rate = input_fare;
    }
}
