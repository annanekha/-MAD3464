/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Airline;

import java.sql.ResultSet;
import java.util.Scanner;

/**
 *
 * @author annanekhashabu
 */

/**
 *
 * class to manage the ticket rates with different airlines.
 */

public class Ticket extends Passenger 
{
    public char char_confirm;
    public String sql_query = "";
    
    public ResultSet res ;
   //  public DBConnection DB_object ;
    
    Scanner object = new Scanner(System.in);

    
    
    
    
    
    // compare price of ticket rates with different airlines.
    public void compPrice(String itenary,String date)
    {
        System.out.println("Fare comparison...");
        
        System.out.println("Enter the type of seat from the list  to reserve :");
        System.out.println("1. First Class \n2. Business class\n3. Economy");
           super.seat_type = input.nextLine();
        
           switch (super.seat_type)
               
            {
                case "1" : {
                              super.seat_type = "First Class";
                              break;
                           }
                
                case "2" : {
                              super.seat_type = "business";
                              break;
                           }
                
                case "3" : {  
                              super.seat_type = "economy";
                              break;
                           }
            }
      
        
        System.out.println("Please find below the list of flights with itenary no #" + itenary);
    
        
        // code to pull the flight details with same itenary and class from DB
        //*******************************************************************************
          sql_query = "SELECT flightNo,A.airline,depart_date,fare_rate FROM flightrepo A INNER JOIN farechart B WHERE A.flightNo = B.flight_no and itenary_id = '"+itenary+"' and depart_date = '"+ date +"' and B.class = '"+this.seat_type+"';" ;
       // System.err.println("query= " + sql_query);
          try {
                res = DB_object.executeSQL(sql_query);
                
                while (res.next())
                 {
                     System.out.println(">>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<");
                     System.out.println("Flight no   :" + res.getString(1));
                     System.out.println("Airline     :" + res.getString(2));
                     System.out.println("Depart Date :" + res.getString(3));
                     System.out.println("Fare        :" + res.getString(4));
                 }
                
              } 
          catch (Exception e) 
            {
                System.err.println("SQL Exception : " + e);
            }
          
        //*******************************************************************************
        
        
    }
    
   
}
