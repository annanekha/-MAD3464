/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Airline;

import com.mysql.jdbc.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import javax.naming.spi.DirStateFactory;

/**
 *
 * @author annanekhashabu
 */


/**
 *
 * class which manages the itinerary of services.
 */
public class itenary 

{
    
    public String startPoint,endPoint = "";
    public double airmiles = 0;
    public String itenaryID = "";
    public String sql_query = "";
    public ResultSet res ;
    public DBConnection DB_object ;
    
    
    

    public itenary() 
    {
       DB_object = new DBConnection();
      //DB_object.connect();  
       
    }
    
    
    
    // getter method for itenary
    public void display_itenaries()        
    
    {                   
                            // code to retrieve data from the DB and store in class variables.
                            //********************************************************************************
                                try {
                                       sql_query = "select * from itenary";                         
                                       res = DB_object.executeSQL(sql_query);                   
                                     }
                             catch (SQLException e) 
                                     {
                                         System.out.println("Sql Exception : " + e);
                                     }
                                
                                
                                try {
                                         while(res.next())
                                       {
                                           System.out.println(">>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<");
                                           System.out.println("Itenary ID :" + res.getString(1));
                                           System.out.println("Starting destination :" + res.getString(2));
                                           System.out.println("End destination :" + res.getString(3));
                                           System.out.println("Airmiles :" + res.getString(4));
                                       }
                                    } catch (Exception e)
                                      {
                                          System.err.println("Exception at try-catch for pulling itenary DB records  .. class: itenary --> method : display_itenaries() --> " + e);
                                      }
            
                            //********************************************************************************
        
                            
    }
    
    // setter method for itenary 
    public void insert_new_itenary() throws SQLException       
    
    {
                           
                           
                            Scanner input = new Scanner(System.in);
        
                            System.out.println("<<<<<<<< Welcome to the Airline reservation system >>>>>>>\n");
                            System.out.println("<<<<<<<<<<<<<<<<<<<<< Insert new itenary >>>>>>>>>>>>>>>>>>");
                            System.out.println("\n\n");
                           
                            System.out.println("Enter new stating destination ;");
                            this.startPoint = input.nextLine();
                            
                            System.out.println("Enter new final destination ;");
                            this.endPoint = input.nextLine();
                            
                            System.out.println("Enter the total airmiles between destinations :");
                            this.airmiles = input.nextDouble();
                            
                            // code to insert data into DB.
                            //*******************************************************************************************
                             try {
                                    
                                   // sql_query = "insert into itenary(startPoint,endPoint,airmiles) VALUES('"+ this.startPoint +"' ,'"+ this.endPoint +"','"+ this.airmiles +");";                               
                                    sql_query = "insert into itenary(startPoint,endPoint,airmiles) VALUES( '"+ this.startPoint +"' , '"+ this.endPoint +"', '"+this.airmiles+"');";                      
                                    
                                    DB_object.executeSQL_update(sql_query);
                                    System.out.println("New itenary added successfully !!! ");
                                    
                                    
                                 }
                             catch (SQLException e) 
                                     {
                                         System.out.println("Sql Exception : " + e);
                                     }
                            
                            
                            //*******************************************************************************************
    }
    
        
    
}
