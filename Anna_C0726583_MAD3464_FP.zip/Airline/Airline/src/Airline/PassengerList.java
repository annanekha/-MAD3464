/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Airline;

import com.sun.xml.internal.stream.Entity;
import java.sql.SQLException;
import java.util.Scanner;

/**
 *
 * @author annanekhashabu
 */

/**
 * PassengerList - class to handle the passenger list
 * 
 */
public class PassengerList extends Passenger implements seat
{

    String reservation_id,passenger_id,pass_sql_query_insert,list_pass_sql_query, pass_sql_query_delete;
    Scanner input = new Scanner(System.in);
    Integer seat = 0;
    boolean flag ;
    
    
    // method to add a new passenger's reservation to the list
 /**
 * addPassenger() - method to add a new passenger.
 * 
 */
    public void addPassenger()
    {
        System.out.println("Enter the passenger name :");
        this.passenger_id = input.nextLine();
        
        System.out.println("Enter the number of seats required : ");
        set_seat();
        
        System.out.println("Adding passenger details to passenger list : ");
        
        // code to add details of passenger into DB.
        //**********************************************************************************
        // code to add details of passenger name and reservation id and seat to DB
       
        // 	pass_id 	pass_name 	seats 
        pass_sql_query_insert = "insert into pass_list (pass_name,seats) VALUES( '"+ this.passenger_id +"','"+ this.seat +"');";                      
                  
        try {
                DB_object.executeSQL_update(pass_sql_query_insert);
                flag = true;
            } 
        catch (Exception e) 
           {
                System.out.println("Sql Exception found at : method : addPassenger(String pass_name)class : PassengerList " +e );
           }
       
             
       
        //**********************************************************************************
      
        if (flag)
        {
            System.out.println("Passenger added to passenger list successfully !");
        }
        else
        {
            System.out.println("passenger list updation failed !!");
        }
        
    }
    
    
    // method to remove a new passenger to the list
 /**
 * removePassenger() - method to remove a passenger from the list.
 * 
 */
    public void removePassenger()
    {
        
        System.out.println("Passenger removal panel.");
        this.listPass();

        System.out.println("Enter the passenger id from the above list to proceed with removal process.");
        this.passenger_ID = input.nextLine();
   
        //**********************************************************************************
        // code to remove details of passenger from DB.
        pass_sql_query_delete  = "DELETE from pass_list WHERE pass_id = '"+this.passenger_ID+"';";
         
        try 
         {
             DB_object.executeSQL_update(pass_sql_query_delete );
             if(DB_object.result > 0) 
             {
                flag = true;
             }    
             else
             {
                flag = false;
             }      
             
         } 
        
        catch (Exception e)
         {
             System.out.println("SQL Exception . class : flightrepo.. method : removeFlight() " + e);
         }
        
   
        
        //**********************************************************************************
      
        if (flag)
        {
            System.out.println("Passenger removed from  passenger list successfully !");
        }
        else
        {
            System.out.println("Removal process failed !!");
        }
        
    }
    
    // method to list the passenger list from DB.
 /**
 * listPass() - method to list the passenger list.
 * 
 */
     public void listPass()
    {
       
        try {
              list_pass_sql_query = "select * from pass_list;";                         
              res = DB_object.executeSQL(list_pass_sql_query);                   
            }
                               
        catch (SQLException e) 
            {
               System.out.println("Sql Exception in reading data from DB: method : listPass()  : class : PassengerList" + e);
            }
                                
        try {
              while(res.next())
                {   
                   System.out.println(">>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<");
                   System.out.println("Pasenger ID#   :" + res.getString(1));
                   System.out.println("Passenger name :" + res.getString(2));
                   System.out.println("No of seats reserved :" + res.getString(3));   
                          
                   flag = true;
                }
            } 
                                
        catch (Exception e)
            {
              System.err.println("Exception at try-catch for pulling itenary DB records  .. class: flightRepo --> method : listFlight(String itenary_id, String dept_date) --> " + e);
            }
    }
    
   
    
    @Override
    
    public void set_seat() 
    {
        this.seat = input.nextInt();
    }
    
}
