/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Airline;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author annanekhashabu
 */


/**
 *
 * Class that manages the list of flights as per the different vendors.
 */
public class FRepository extends flight
{
    private ArrayList <flight> flight_list  = new ArrayList<flight> ();         //list of the flights.
    private String service_provider_name;
    public String sql_query = "";
    public ResultSet res ;
    public DBConnection DB_object ;
    public Boolean flag = false;
    public String flight_sql_query_insert = "";
    public String flight_sql_query_delete = "";
    public String remove_fight_number = "";

    public FRepository()
    {
        DB_object = new DBConnection();
    }
    
    
    
    //method to add a brand new fight to the repository.
    public void addFlight()           
    {
        System.out.println("Pooling up the flight details :");   
        flight temp_object = new flight();
        temp_object.chart_flight();
            
       //********************************************************************************************
       // code to write data into to DB.
        flight_sql_query_insert = "insert into flightrepo (flightNo,airline,itenary_id,depart_date,depart_time,pilot_name) VALUES( '"+ temp_object.flight_no +"' , '"+ temp_object.airline_name +"','"+  temp_object.flight_itenary_ID+"', '"+temp_object.depart_date+"','"+ temp_object.depart_time +"','"+temp_object.pilot_name+"');";                      
                  
        try {
                DB_object.executeSQL_update(flight_sql_query_insert);
                flag = true;
            } 
        catch (Exception e) 
           {
                System.out.println("Sql Exception found at : " +e );
           }
       if(flag)
                System.out.println("Flight added successfully !! ");
                
       //********************************************************************************************
        
    }
    
    //method to remove a fight to the repository.
    public void removeFlight()
    {
        this.listFlight();                  // method to display the list of the added flights.                                      
        System.out.println("Enter the flight number to be removed from list :");
        remove_fight_number = input.nextLine();
        
        flight_sql_query_delete  = "DELETE from flightrepo WHERE flightNo = '"+this.remove_fight_number+"';";
         
        try 
         {
             DB_object.executeSQL_update(flight_sql_query_delete);
             if(DB_object.result > 0) 
             {
                System.out.println("Flight is deleted successfully!");
             }    
             else
             {
                System.out.println("Failed !!");
             }      
             
         } catch (Exception e)
         {
             System.out.println("SQL Exception . class : flightrepo.. method : removeFlight() " + e);
         }
        
        
    }
    
    
    //  listFlight() - method 1 : method to list all the flight numbers from DB.
    public void listFlight()
    {
       
        try {
              
              sql_query = "select * from flightrepo;";                         
              res = DB_object.executeSQL(sql_query);                   
            }
                               
        catch (SQLException e) 
            {
               System.out.println("Sql Exception in reading data from DB: method : listFlight()  : class : flightRepo" + e);
            }
                                
        try {
              while(res.next())
                {   
                   System.out.println("#################################################");
                   System.out.println("Flight no#  :" + res.getString(1));
                   System.out.println("Airline     :" + res.getString(2));
                   System.out.println("Itenary ID  :" + res.getString(3));   
                   System.out.println("Depart date :" + res.getString(4));
                   System.out.println("Depart time :" + res.getString(5));
                   System.out.println("Pilot name  :" + res.getString(6));
                                           
                   flag = true;
                }
            } 
                                
        catch (Exception e)
            {
              System.err.println("Exception at try-catch for pulling itenary DB records  .. class: flightRepo --> method : listFlight(String itenary_id, String dept_date) --> " + e);
            }
    }
    
    
    // listFlight() - method 2 : method to display the list of flights as per the given itenary and departure date.
     public boolean listFlight(String itenary_id, String dept_date)
    {
                             // code to retrieve data from the DB as per the given itenary_id and dept date
                             // table : flihtrepo, keys : itenary_id, depart_date
                             //********************************************************************************
                                try {
                                    // flightNo	airline	itenary_id	depart_date Ascending 1	pilot_name
                                       sql_query = "select flightNo,itenary_id,airline,depart_date from flightrepo where itenary_id = '"+ itenary_id +"' and depart_date = '"+ dept_date +"';";                         
                                       System.out.println(sql_query);
                                       res = DB_object.executeSQL(sql_query);                   
                                    }
                               
                                catch (SQLException e) 
                                     {
                                         System.out.println("Sql Exception : " + e);
                                     }
                                
                                try {
                                         while(res.next())
                                       {   
                                           System.out.println(">>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<");
                                           System.out.println("Flight no#  :" + res.getString(1));
                                           System.out.println("Airline     :" + res.getString(2));
                                           System.out.println("Itenary ID  :" + res.getString(3));
                                           System.out.println("Depart date :" + res.getString(4));
                                           
                                           flag = true;
                                       }
                                    } 
                                
                                catch (Exception e)
                                      {
                                          System.err.println("Exception at try-catch for pulling itenary DB records  .. class: flightRepo --> method : listFlight(String itenary_id, String dept_date) --> " + e);
                                      }
                                if (!flag)    // flag == false
                                    
                                {
                                    System.out.println("No flights found !! Please check the itenary no and departure date.");
                                    return false;
                                }
                                else
                                {
                                    return true;
                                }
       
    }

}
